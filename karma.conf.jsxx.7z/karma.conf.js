var webpackConfig = require('./webpack.config.js');
webpackConfig.mode='development';
module.exports = function(config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine'],
    files: [
      'spec/*-spec.js'
    ],
    preprocessors: {
      'spec/*-spec.js': ['webpack'],
    },
    webpack: webpackConfig, 
    reporters: ['mocha'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_DEBUG,
    autoWatch: true,
    browsers: ['Chrome'],
    singleRun: false,
    concurrency: Infinity
  })
}